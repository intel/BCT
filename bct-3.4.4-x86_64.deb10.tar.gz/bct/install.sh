#!/usr/bin/env bash
# Copyright (c) 2022 Intel Corporation All Rights Reserved.
#
# The source code contained or described herein and all documents related to
# the source code (Material) are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or
# disclosed in any way without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.

mkdir -p ~/.local/bin
ret=$?
if [ $ret -ne 0 ]; then
  exit $ret
fi
if [ -d ~/.local/bin/bct ]; then
   rm -fr ~/.local/bin/bct
fi
cp -r ../bct ~/.local/bin/
ret=$?
if [ $ret -ne 0 ]; then
  exit $ret
fi
mkdir -p ~/.local/share/applications
ret=$?
if [ $ret -ne 0 ]; then
  rm -fr ~/.local/bin/bct
  exit $ret
fi
user_homedir=$(echo ~)
cat >~/.local/share/applications/bct.desktop <<EOL
[Desktop Entry]
Name=BCT
Comment=Intel(R) Firmware Support Package Binary Configuration Tool
Keywords=programming;firmware;fsp
Exec=${user_homedir}/.local/bin/bct/bct
Terminal=false
Type=Application
StartupNotify=false
Icon=bct
Categories=Development
EOL
ret=$?
if [ $ret -ne 0 ]; then
  rm -fr ~/.local/bin/bct
  exit $ret
fi
pushd icons
for d in */ ; do
    mkdir -p ~/.local/share/icons/hicolor/$d/apps
    ret=$?
    if [ $ret -eq 0 ]; then
        cp -r $d/. ~/.local/share/icons/hicolor/$d/apps
    fi
done
popd
if command -v zenity &> /dev/null; then
    zenity --info --text "Installation of BCT was successful!"
else
    echo "Installation of BCT was successful!"
fi
